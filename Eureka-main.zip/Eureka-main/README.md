# Eureka
 This is a personal voice assistant made in python helps user to do tasks.
